/**
 * Static File Server + API Proxy
 * Port: 60023
 * 
 * - Serves static HTML/CSS/JS
 * - Proxies API requests to Next.js backend (port 3000)
 */

const PORT = 60023;
const API_BACKEND = 'http://localhost:3000';
const PUBLIC_DIR = './public';

// MIME types
const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
};

// CORS headers
const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-key',
  'Access-Control-Max-Age': '86400',
};

// Serve static file
async function serveStatic(pathname: string): Promise<Response | null> {
  // Default to index.html
  if (pathname === '/' || pathname === '') {
    pathname = '/index.html';
  }

  const filePath = `${PUBLIC_DIR}${pathname}`;
  
  try {
    const file = Bun.file(filePath);
    const exists = await file.exists();
    
    if (!exists) {
      return null;
    }

    const ext = pathname.substring(pathname.lastIndexOf('.'));
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    return new Response(file, {
      headers: {
        'Content-Type': contentType,
        ...CORS_HEADERS,
      },
    });
  } catch (error) {
    return null;
  }
}

// Proxy API request to backend
async function proxyAPI(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const targetUrl = `${API_BACKEND}${url.pathname}${url.search}`;

  console.log(`[PROXY] ${request.method} ${url.pathname} -> ${targetUrl}`);

  try {
    // Forward the request
    const proxyRequest = new Request(targetUrl, {
      method: request.method,
      headers: request.headers,
      body: request.body,
    });

    const response = await fetch(proxyRequest);

    // Clone response with CORS headers
    const proxyResponse = new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers: {
        ...Object.fromEntries(response.headers),
        ...CORS_HEADERS,
      },
    });

    return proxyResponse;
  } catch (error) {
    console.error('[PROXY ERROR]', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Backend server unavailable' 
    }), {
      status: 502,
      headers: {
        'Content-Type': 'application/json',
        ...CORS_HEADERS,
      },
    });
  }
}

// Main server
const server = Bun.serve({
  port: PORT,
  
  async fetch(request) {
    const url = new URL(request.url);
    const pathname = url.pathname;

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: CORS_HEADERS,
      });
    }

    // API routes - proxy to Next.js backend
    if (pathname.startsWith('/api/')) {
      return proxyAPI(request);
    }

    // Static files
    const staticResponse = await serveStatic(pathname);
    if (staticResponse) {
      return staticResponse;
    }

    // Fallback to index.html for SPA routes
    const indexResponse = await serveStatic('/index.html');
    if (indexResponse) {
      return indexResponse;
    }

    // 404
    return new Response('Not Found', {
      status: 404,
      headers: CORS_HEADERS,
    });
  },

  error(error) {
    console.error('[SERVER ERROR]', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: 'Internal Server Error' 
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
        ...CORS_HEADERS,
      },
    });
  },
});

console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🚀 Auth Service - Static Server                         ║
║                                                           ║
║   Port: ${PORT}                                            ║
║   URL:  http://localhost:${PORT}                            ║
║   API:  ${API_BACKEND} (proxied)                           ║
║                                                           ║
║   Static files: ${PUBLIC_DIR}/                              ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
`);

export default server;
