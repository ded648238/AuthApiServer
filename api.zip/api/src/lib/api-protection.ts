/**
 * API Protection utilities
 */

import { NextRequest, NextResponse } from 'next/server'
import { db } from './db'

interface ValidatedClient {
  id: string
  email: string
  webhookUrl: string | null
}

export function validateEmail(email: string): { valid: boolean; error?: string } {
  if (!email || typeof email !== 'string') return { valid: false, error: 'Email required' }
  if (email.length > 254) return { valid: false, error: 'Email too long' }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { valid: false, error: 'Invalid email' }
  return { valid: true }
}

export function validatePassword(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = []
  if (!password || typeof password !== 'string') return { valid: false, errors: ['Password required'] }
  if (password.length < 8) errors.push('Min 8 chars')
  if (password.length > 128) errors.push('Max 128 chars')
  return { valid: errors.length === 0, errors }
}

export function sanitizeString(input: string, maxLength = 1000): string {
  return input.substring(0, maxLength).trim()
}

export async function protectApiEnhanced(request: NextRequest): Promise<{ 
  success: boolean
  client?: ValidatedClient
  error?: string
  status?: number
  response?: NextResponse 
}> {
  const apiKey = request.headers.get('x-api-key') || request.headers.get('X-Api-Key')
  
  if (!apiKey) {
    return {
      success: false,
      error: 'API key required',
      status: 401,
      response: NextResponse.json({ success: false, error: 'API key required' }, { status: 401 })
    }
  }
  
  if (!apiKey.startsWith('auth_') || apiKey.length < 20) {
    return {
      success: false,
      error: 'Invalid API key',
      status: 401,
      response: NextResponse.json({ success: false, error: 'Invalid API key' }, { status: 401 })
    }
  }
  
  try {
    const client = await db.client.findUnique({
      where: { apiKey },
      select: { id: true, email: true, webhookUrl: true }
    })
    
    if (!client) {
      return {
        success: false,
        error: 'Invalid API key',
        status: 401,
        response: NextResponse.json({ success: false, error: 'Invalid API key' }, { status: 401 })
      }
    }
    
    return { success: true, client: client as ValidatedClient }
  } catch (error) {
    console.error('DB error:', error)
    return {
      success: false,
      error: 'Server error',
      status: 500,
      response: NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
    }
  }
}
