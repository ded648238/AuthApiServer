/**
 * ============================================
 * MIDDLEWARE ДЛЯ ЗАЩИТЫ API
 * ============================================
 * 
 * Этот middleware проверяет наличие правильного API-ключа
 * в заголовке запроса перед тем, как разрешить доступ к API.
 * 
 * КАК ЭТО РАБОТАЕТ:
 * 1. Разработчик получает API-ключ в админ-панели
 * 2. Его сайт отправляет запросы с заголовком: x-api-key: auth_...
 * 3. Middleware проверяет ключ в базе данных
 * 4. Если ключ валиден - запрос продолжается
 * 5. Если нет - возвращается ошибка 401 Unauthorized
 * 
 * ПРИМЕР ЗАПРОСА:
 * fetch('/api/register', {
 *   method: 'POST',
 *   headers: {
 *     'Content-Type': 'application/json',
 *     'x-api-key': 'auth_a1b2c3d4...'
 *   },
 *   body: JSON.stringify({ username: 'user', password: 'pass' })
 * })
 */

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Расширяем тип Request для хранения данных клиента
declare global {
  interface Request {
    client?: {
      id: string
      email: string
      webhookUrl: string | null
    }
  }
}

/**
 * Проверяет API-ключ и возвращает информацию о клиенте
 * 
 * @param request - Next.js запрос
 * @returns Client данные или null если ключ невалиден
 */
export async function authenticateApiKey(request: NextRequest) {
  // Получаем API-ключ из заголовка
  // Поддерживаем оба варианта написания для удобства
  const apiKey = request.headers.get('x-api-key') || 
                 request.headers.get('X-Api-Key')
  
  if (!apiKey) {
    return { error: 'API key is required in x-api-key header', status: 401 }
  }
  
  // Проверяем формат ключа (должен начинаться с 'auth_')
  if (!apiKey.startsWith('auth_')) {
    return { error: 'Invalid API key format', status: 401 }
  }
  
  // Ищем клиента по API-ключу в базе данных
  const client = await db.client.findUnique({
    where: { apiKey },
    select: {
      id: true,
      email: true,
      webhookUrl: true
    }
  })
  
  if (!client) {
    return { error: 'Invalid API key', status: 401 }
  }
  
  return { client }
}

/**
 * Higher-Order Function для защиты API endpoints
 * 
 * ИСПОЛЬЗОВАНИЕ:
 * 
 * export async function POST(request: NextRequest) {
 *   const auth = await protectApi(request)
 *   if (auth.error) {
 *     return auth.response
 *   }
 *   
 *   // auth.client доступен здесь
 *   const clientId = auth.client!.id
 *   // ... логика endpoint
 * }
 * 
 * @param request - Next.js запрос
 * @returns Объект с клиентом или ошибкой
 */
export async function protectApi(request: NextRequest) {
  const apiKey = request.headers.get('x-api-key') || 
                 request.headers.get('X-Api-Key')
  
  if (!apiKey) {
    return {
      error: 'API key is required',
      status: 401,
      response: NextResponse.json(
        { 
          success: false, 
          error: 'API key is required in x-api-key header' 
        },
        { status: 401 }
      )
    }
  }
  
  if (!apiKey.startsWith('auth_')) {
    return {
      error: 'Invalid API key format',
      status: 401,
      response: NextResponse.json(
        { 
          success: false, 
          error: 'Invalid API key format' 
        },
        { status: 401 }
      )
    }
  }
  
  const client = await db.client.findUnique({
    where: { apiKey },
    select: {
      id: true,
      email: true,
      webhookUrl: true
    }
  })
  
  if (!client) {
    return {
      error: 'Invalid API key',
      status: 401,
      response: NextResponse.json(
        { 
          success: false, 
          error: 'Invalid API key' 
        },
        { status: 401 }
      )
    }
  }
  
  return { client: client as { id: string; email: string; webhookUrl: string | null } }
}
