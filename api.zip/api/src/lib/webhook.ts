/**
 * ============================================
 * WEBHOOK СИСТЕМА УВЕДОМЛЕНИЙ
 * ============================================
 * 
 * Webhooks позволяют разработчикам получать уведомления
 * о событиях на их сайтах в реальном времени.
 * 
 * КАК ЭТО РАБОТАЕТ:
 * 1. Разработчик указывает URL своего сервера в админке
 * 2. При регистрации нового пользователя наш сервер
 *    отправляет POST-запрос на этот URL
 * 3. Сервер разработчика обрабатывает уведомление
 * 
 * ПРИМЕР ИСПОЛЬЗОВАНИЯ:
 * - Создание профиля пользователя на сайте разработчика
 * - Отправка приветственного email
 * - Аналитика регистраций
 */

import { db } from '@/lib/db'

// Типы событий webhook
export enum WebhookEvent {
  USER_REGISTERED = 'user.registered',
  USER_LOGIN = 'user.login',
  USER_DELETED = 'user.deleted',
  PASSWORD_RESET = 'password.reset'
}

// Интерфейс данных webhook
export interface WebhookPayload {
  event: WebhookEvent
  timestamp: string
  data: {
    userId?: string
    username?: string
    clientId: string
    [key: string]: unknown
  }
}

/**
 * Отправляет webhook-уведомление разработчику
 * 
 * @param clientId - ID разработчика
 * @param event - Тип события
 * @param data - Данные события
 */
export async function sendWebhook(
  clientId: string,
  event: WebhookEvent,
  data: WebhookPayload['data']
): Promise<void> {
  try {
    // Получаем URL webhook'а разработчика
    const client = await db.client.findUnique({
      where: { id: clientId },
      select: { webhookUrl: true }
    })

    if (!client?.webhookUrl) {
      // У разработчика не настроен webhook - пропускаем
      console.log(`No webhook URL configured for client ${clientId}`)
      return
    }

    // Формируем payload
    const payload: WebhookPayload = {
      event,
      timestamp: new Date().toISOString(),
      data
    }

    // Отправляем POST-запрос на URL разработчика
    const response = await fetch(client.webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Специальный заголовок для проверки подлинности
        'X-Auth-Service-Event': event,
        'X-Auth-Service-Timestamp': payload.timestamp
      },
      body: JSON.stringify(payload)
    })

    if (!response.ok) {
      console.error(`Webhook failed for client ${clientId}: ${response.status}`)
    } else {
      console.log(`Webhook sent successfully to ${client.webhookUrl}`)
    }
  } catch (error) {
    // Не прерываем основной поток при ошибке webhook
    console.error('Webhook error:', error)
  }
}

/**
 * Валидирует URL webhook'а
 * Проверяет что URL:
 * - Начинается с http:// или https://
 * - Не является localhost в продакшене
 */
export function validateWebhookUrl(url: string): boolean {
  try {
    const parsed = new URL(url)
    
    // Проверяем протокол
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return false
    }
    
    // В продакшене можно добавить проверку на localhost
    // if (process.env.NODE_ENV === 'production') {
    //   if (parsed.hostname === 'localhost' || parsed.hostname === '127.0.0.1') {
    //     return false
    //   }
    // }
    
    return true
  } catch {
    return false
  }
}
