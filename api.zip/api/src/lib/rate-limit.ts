/**
 * Rate Limiting
 */

import { NextRequest, NextResponse } from 'next/server'

interface RateLimitRecord {
  count: number
  resetTime: number
}

const store = new Map<string, RateLimitRecord>()

export const RATE_LIMIT_CONFIGS = {
  auth: { windowMs: 60000, maxRequests: 100 },
  api: { windowMs: 60000, maxRequests: 1000 },
  read: { windowMs: 60000, maxRequests: 2000 }
}

type RateLimitType = keyof typeof RATE_LIMIT_CONFIGS

function getIP(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for')
  return forwarded ? forwarded.split(',')[0].trim() : 'unknown'
}

export function applyRateLimit(request: NextRequest, type: RateLimitType = 'api') {
  const config = RATE_LIMIT_CONFIGS[type]
  const ip = getIP(request)
  const now = Date.now()
  
  let record = store.get(ip)
  
  if (!record || record.resetTime < now) {
    record = { count: 0, resetTime: now + config.windowMs }
  }
  
  record.count++
  store.set(ip, record)
  
  if (record.count > config.maxRequests) {
    return {
      success: false,
      remaining: 0,
      response: NextResponse.json(
        { success: false, error: 'Rate limit exceeded' },
        { status: 429 }
      )
    }
  }
  
  return {
    success: true,
    remaining: config.maxRequests - record.count
  }
}

export function addRateLimitHeaders(
  response: NextResponse,
  type: RateLimitType,
  remaining: number,
  resetTime: number
) {
  response.headers.set('X-RateLimit-Limit', String(RATE_LIMIT_CONFIGS[type].maxRequests))
  response.headers.set('X-RateLimit-Remaining', String(remaining))
  response.headers.set('X-RateLimit-Reset', String(Math.floor(resetTime / 1000)))
}
