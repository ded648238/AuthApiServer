/**
 * ============================================
 * УТИЛИТЫ АУТЕНТИФИКАЦИИ
 * ============================================
 * 
 * Этот файл содержит все необходимые функции для:
 * - Хеширования и проверки паролей (bcrypt)
 * - Генерации и верификации JWT-токенов
 * - Генерации уникальных API-ключей
 * 
 * КРИПТОГРАФИЧЕСКИЕ ОСНОВЫ:
 * -------------------------
 * 1. bcrypt - адаптивная хеш-функция для паролей
 *    - Добавляет "соль" (salt) - случайные данные
 *    - Замедляет подбор паролей (cost factor)
 *    - Защищает от радужных таблиц
 * 
 * 2. JWT (JSON Web Token) - компактный токен для авторизации
 *    - Состоит из: Header.Payload.Signature
 *    - Подписывается секретным ключом (HMAC)
 *    - Содержит claims (утверждения о пользователе)
 */

import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'
import { randomBytes } from 'crypto'

// ============================================
// КОНФИГУРАЦИЯ БЕЗОПАСНОСТИ
// ============================================

// Секретный ключ для подписи JWT-токенов
// В продакшене должен храниться в переменных окружения!
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-jwt-key-change-in-production'

// Стоимость хеширования bcrypt (10-12 - хороший баланс безопасности и производительности)
// Чем выше число, тем медленнее хеширование, но безопаснее
const BCRYPT_ROUNDS = 12

// Срок жизни JWT-токена (1 час)
const JWT_EXPIRES_IN = '1h'

// Срок жизни токена сброса пароля (1 час в секундах)
const PASSWORD_RESET_EXPIRES = 60 * 60 // 1 час

// ============================================
// ХЕШИРОВАНИЕ ПАРОЛЕЙ (bcrypt)
// ============================================

/**
 * Хеширует пароль с использованием bcrypt
 * 
 * КАК ЭТО РАБОТАЕТ:
 * 1. bcrypt генерирует случайную "соль" (salt)
 * 2. Соль комбинируется с паролем
 * 3. Применяется алгоритм Blowfish многократно (BCRYPT_ROUNDS раз)
 * 4. Результат сохраняется в формате: $2b$12$[22 символа соли][31 символ хеша]
 * 
 * @param password - Пароль в открытом виде
 * @returns Хешированный пароль
 */
export async function hashPassword(password: string): Promise<string> {
  // bcrypt.hash автоматически генерирует соль и добавляет её к хешу
  // Это позволяет хранить соль и хеш вместе в одной строке
  return bcrypt.hash(password, BCRYPT_ROUNDS)
}

/**
 * Проверяет пароль против хеша
 * 
 * КАК ЭТО РАБОТАЕТ:
 * 1. Извлекает соль из сохранённого хеша
 * 2. Хеширует введённый пароль с той же солью
 * 3. Сравнивает полученные хеши
 * 
 * @param password - Пароль в открытом виде
 * @param hashedPassword - Сохранённый хеш пароля
 * @returns true если пароль верный
 */
export async function verifyPassword(
  password: string, 
  hashedPassword: string
): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword)
}

// ============================================
// JWT-ТОКЕНЫ (JSON Web Tokens)
// ============================================

/**
 * Интерфейс для данных в JWT-токене
 */
export interface JWTPayload {
  userId: string      // ID пользователя
  username: string    // Имя пользователя
  clientId: string    // ID разработчика (чей API использовался)
  iat?: number        // Время создания (автоматически добавляется)
  exp?: number        // Время истечения (автоматически добавляется)
}

/**
 * Генерирует JWT-токен для авторизованного пользователя
 * 
 * СТРУКТУРА JWT:
 * {
 *   "header": {
 *     "alg": "HS256",    // Алгоритм подписи
 *     "typ": "JWT"       // Тип токена
 *   },
 *   "payload": {
 *     "userId": "...",
 *     "username": "...",
 *     "clientId": "...",
 *     "iat": 1234567890,  // Issued At - время создания
 *     "exp": 1234571490   // Expiration - время истечения
 *   },
 *   "signature": "..."    // Подпись для проверки целостности
 * }
 * 
 * @param payload - Данные для включения в токен
 * @returns JWT-токен в виде строки
 */
export function generateJWT(payload: JWTPayload): string {
  // jwt.sign создаёт токен:
  // 1. Кодирует header и payload в Base64
  // 2. Создаёт подпись с помощью HMAC-SHA256
  // 3. Объединяет всё в формате header.payload.signature
  return jwt.sign(payload, JWT_SECRET, { 
    expiresIn: JWT_EXPIRES_IN,
    issuer: 'auth-service' // Кто выдал токен
  })
}

/**
 * Проверяет и декодирует JWT-токен
 * 
 * ПРОВЕРКИ:
 * 1. Формат токена (3 части, разделённые точками)
 * 2. Подпись (используя секретный ключ)
 * 3. Срок действия (exp claim)
 * 4. Издатель (iss claim)
 * 
 * @param token - JWT-токен
 * @returns Декодированные данные или null если токен невалиден
 */
export function verifyJWT(token: string): JWTPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET, {
      issuer: 'auth-service'
    }) as JWTPayload
    return decoded
  } catch (error) {
    // Токен невалиден: истёк срок, неверная подпись или неправильный формат
    console.error('JWT verification failed:', error)
    return null
  }
}

// ============================================
// API-КЛЮЧИ
// ============================================

/**
 * Генерирует уникальный API-ключ
 * 
 * ФОРМАТ: auth_[32 случайных байта в hex]
 * Пример: auth_a1b2c3d4e5f6... (64 символа после префикса)
 * 
 * @returns API-ключ в виде строки
 */
export function generateApiKey(): string {
  // randomBytes - криптографически стойкий генератор случайных чисел
  // 32 байта = 64 hex символа
  const randomString = randomBytes(32).toString('hex')
  return `auth_${randomString}`
}

// ============================================
// ТОКЕНЫ СБРОСА ПАРОЛЯ
// ============================================

/**
 * Генерирует токен для сброса пароля
 * 
 * @returns Объект с токеном и временем истечения
 */
export function generatePasswordResetToken(): { 
  token: string
  expiresAt: Date 
} {
  // Генерируем случайный токен
  const token = randomBytes(32).toString('hex')
  
  // Время истечения - через 1 час
  const expiresAt = new Date(Date.now() + PASSWORD_RESET_EXPIRES * 1000)
  
  return { token, expiresAt }
}

// ============================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================

/**
 * Извлекает IP-адрес из запроса Next.js
 * Учитывает прокси и load balancers
 */
export function getClientIP(request: Request): string {
  // Проверяем заголовки прокси
  const forwardedFor = request.headers.get('x-forwarded-for')
  if (forwardedFor) {
    // x-forwarded-for может содержать несколько IP, берём первый
    return forwardedFor.split(',')[0].trim()
  }
  
  // Если прокси нет, возвращаем заголовок или дефолт
  return request.headers.get('x-real-ip') || 'unknown'
}

/**
 * Извлекает User-Agent из запроса
 */
export function getUserAgent(request: Request): string {
  return request.headers.get('user-agent') || 'unknown'
}
