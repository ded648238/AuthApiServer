/**
 * ============================================
 * SEED - СОЗДАНИЕ АДМИН-АККАУНТА
 * ============================================
 * 
 * Создаёт администратора при первом запуске
 */

import { hashPassword, generateApiKey } from './auth'
import { db } from './db'

const ADMIN_EMAIL = 'ded648238@gmail.com'
const ADMIN_PASSWORD = 'Login1234556'

let seedPromise: Promise<void> | null = null

export async function seedAdmin(): Promise<void> {
  // Предотвращаем множественные запуски
  if (seedPromise) {
    return seedPromise
  }
  
  seedPromise = (async () => {
    try {
      // Проверяем, существует ли уже админ
      const existingAdmin = await db.client.findUnique({
        where: { email: ADMIN_EMAIL }
      })
      
      if (existingAdmin) {
        console.log('✅ Admin account already exists')
        return
      }
      
      // Создаём админа
      const passwordHash = await hashPassword(ADMIN_PASSWORD)
      const apiKey = generateApiKey()
      
      await db.client.create({
        data: {
          email: ADMIN_EMAIL,
          passwordHash,
          apiKey
        }
      })
      
      console.log('✅ Admin account created successfully!')
      console.log(`   Email: ${ADMIN_EMAIL}`)
      console.log(`   API Key: ${apiKey}`)
      
    } catch (error) {
      console.error('❌ Failed to create admin account:', error)
    }
  })()
  
  return seedPromise
}
