/**
 * ============================================
 * ЖУРНАЛ АУДИТА БЕЗОПАСНОСТИ
 * ============================================
 * 
 * Audit Logs - это запись всех действий безопасности в системе.
 * Позволяет:
 * - Отслеживать подозрительную активность
 * - Анализировать попытки взлома
 * - Соблюдать требования compliance (GDPR, SOC2)
 * 
 * ЧТО МЫ ЛОГИРУЕМ:
 * - Успешные и неуспешные попытки входа
 * - Регистрации новых пользователей
 * - Сбросы паролей
 * - IP-адреса и User-Agent
 */

import { db } from '@/lib/db'
import { getClientIP, getUserAgent } from './auth'

// Типы действий для аудита
export enum AuditAction {
  // Вход в систему
  LOGIN_SUCCESS = 'LOGIN_SUCCESS',
  LOGIN_FAILED = 'LOGIN_FAILED',
  
  // Регистрация
  REGISTER_SUCCESS = 'REGISTER_SUCCESS',
  REGISTER_FAILED = 'REGISTER_FAILED',
  
  // Сброс пароля
  PASSWORD_RESET_REQUEST = 'PASSWORD_RESET_REQUEST',
  PASSWORD_RESET_SUCCESS = 'PASSWORD_RESET_SUCCESS',
  PASSWORD_RESET_FAILED = 'PASSWORD_RESET_FAILED',
  
  // Управление API
  API_KEY_GENERATED = 'API_KEY_GENERATED',
  
  // Webhook
  WEBHOOK_UPDATED = 'WEBHOOK_UPDATED',
  
  // Удаление
  USER_DELETED = 'USER_DELETED',
  USER_RESTORED = 'USER_RESTORED'
}

// Интерфейс для создания записи аудита
interface CreateAuditLogParams {
  clientId: string
  action: AuditAction
  username?: string
  request?: Request
  status: 'success' | 'failed'
  details?: Record<string, unknown>
}

/**
 * Создаёт запись в журнале аудита
 * 
 * @param params - Параметры записи
 */
export async function createAuditLog(params: CreateAuditLogParams): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        clientId: params.clientId,
        username: params.username,
        ipAddress: params.request ? getClientIP(params.request) : null,
        userAgent: params.request ? getUserAgent(params.request) : null,
        action: params.action,
        status: params.status,
        details: params.details ? JSON.stringify(params.details) : null
      }
    })
  } catch (error) {
    // Ошибка логирования не должна прерывать основной поток
    console.error('Failed to create audit log:', error)
  }
}

/**
 * Получает статистику аудита для разработчика
 * 
 * @param clientId - ID разработчика
 * @param days - Количество дней для анализа (по умолчанию 30)
 */
export async function getAuditStats(clientId: string, days: number = 30) {
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)
  
  // Получаем все логи за период
  const logs = await db.auditLog.findMany({
    where: {
      clientId,
      createdAt: { gte: startDate }
    },
    orderBy: { createdAt: 'desc' }
  })
  
  // Подсчитываем статистику
  const stats = {
    totalEvents: logs.length,
    successfulLogins: logs.filter(l => l.action === AuditAction.LOGIN_SUCCESS).length,
    failedLogins: logs.filter(l => l.action === AuditAction.LOGIN_FAILED).length,
    registrations: logs.filter(l => l.action === AuditAction.REGISTER_SUCCESS).length,
    passwordResets: logs.filter(l => l.action === AuditAction.PASSWORD_RESET_SUCCESS).length,
    
    // Группировка по дням для графика
    eventsByDay: groupByDay(logs),
    
    // Уникальные IP-адреса
    uniqueIPs: [...new Set(logs.map(l => l.ipAddress).filter(Boolean))],
    
    // Последние события
    recentEvents: logs.slice(0, 10)
  }
  
  return stats
}

/**
 * Группирует события по дням для построения графика
 */
function groupByDay(logs: { createdAt: Date; action: string; status: string }[]) {
  const byDay: Record<string, { date: string; total: number; success: number; failed: number }> = {}
  
  for (const log of logs) {
    const date = log.createdAt.toISOString().split('T')[0]
    
    if (!byDay[date]) {
      byDay[date] = { date, total: 0, success: 0, failed: 0 }
    }
    
    byDay[date].total++
    if (log.status === 'success') {
      byDay[date].success++
    } else {
      byDay[date].failed++
    }
  }
  
  // Сортируем по дате и возвращаем массив
  return Object.values(byDay).sort((a, b) => a.date.localeCompare(b.date))
}

/**
 * Получает последние N записей аудита
 */
export async function getRecentAuditLogs(clientId: string, limit: number = 50) {
  return db.auditLog.findMany({
    where: { clientId },
    orderBy: { createdAt: 'desc' },
    take: limit
  })
}
