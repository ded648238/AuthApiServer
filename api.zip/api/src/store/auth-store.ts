/**
 * ============================================
 * ХРАНИЛИЩЕ СОСТОЯНИЯ АУТЕНТИФИКАЦИИ
 * ============================================
 * 
 * Zustand store для управления состоянием авторизации
 * в админ-панели.
 */

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface Client {
  id: string
  uid: number
  email: string
  apiKey: string
  webhookUrl: string | null
  role: string
}

interface AuthState {
  client: Client | null
  token: string | null
  isLoading: boolean
  error: string | null
  
  setAuth: (client: Client, token: string) => void
  clearAuth: () => void
  updateClient: (updates: Partial<Client>) => void
  setLoading: (loading: boolean) => void
  setError: (error: string | null) => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      client: null,
      token: null,
      isLoading: false,
      error: null,
      
      setAuth: (client, token) => set({ client, token, error: null }),
      clearAuth: () => set({ client: null, token: null, error: null }),
      updateClient: (updates) => set((state) => ({
        client: state.client ? { ...state.client, ...updates } : null
      })),
      setLoading: (isLoading) => set({ isLoading }),
      setError: (error) => set({ error })
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        client: state.client,
        token: state.token
      })
    }
  )
)
