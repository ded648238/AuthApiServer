/**
 * API управления пользователями
 */

import { NextRequest, NextResponse } from 'next/server'
import { protectApiEnhanced } from '@/lib/api-protection'
import { db } from '@/lib/db'
import { createAuditLog, AuditAction } from '@/lib/audit'
import { sendWebhook, WebhookEvent } from '@/lib/webhook'

export async function GET(request: NextRequest) {
  try {
    const protection = await protectApiEnhanced(request, 'read')
    if (!protection.success) {
      return protection.response!
    }
    
    const client = protection.client!
    const { searchParams } = new URL(request.url)
    const includeDeleted = searchParams.get('includeDeleted') === 'true'
    
    const where = {
      clientId: client.id,
      ...(includeDeleted ? {} : { isActive: true })
    }
    
    const users = await db.user.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        username: true,
        isActive: true,
        createdAt: true,
        updatedAt: true
      }
    })
    
    return NextResponse.json({ success: true, users })
    
  } catch (error) {
    console.error('Get users error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const protection = await protectApiEnhanced(request, 'api')
    if (!protection.success) {
      return protection.response!
    }
    
    const client = protection.client!
    
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json({ success: false, error: 'Invalid body' }, { status: 400 })
    }
    
    const { userId } = body as Record<string, unknown>
    
    if (!userId || typeof userId !== 'string') {
      return NextResponse.json({ success: false, error: 'userId required' }, { status: 400 })
    }
    
    const user = await db.user.findFirst({
      where: { id: userId, clientId: client.id }
    })
    
    if (!user) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 })
    }
    
    if (!user.isActive) {
      return NextResponse.json({ success: false, error: 'Already deleted' }, { status: 400 })
    }
    
    // Soft delete
    await db.user.update({
      where: { id: userId },
      data: { isActive: false }
    })
    
    await createAuditLog({
      clientId: client.id,
      action: AuditAction.USER_DELETED,
      username: user.username,
      request,
      status: 'success'
    })
    
    sendWebhook(client.id, WebhookEvent.USER_DELETED, {
      userId: user.id,
      username: user.username
    }).catch(() => {})
    
    return NextResponse.json({ success: true, message: 'User deleted' })
    
  } catch (error) {
    console.error('Delete user error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const protection = await protectApiEnhanced(request, 'api')
    if (!protection.success) {
      return protection.response!
    }
    
    const client = protection.client!
    
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json({ success: false, error: 'Invalid body' }, { status: 400 })
    }
    
    const { userId } = body as Record<string, unknown>
    
    if (!userId || typeof userId !== 'string') {
      return NextResponse.json({ success: false, error: 'userId required' }, { status: 400 })
    }
    
    const user = await db.user.findFirst({
      where: { id: userId, clientId: client.id }
    })
    
    if (!user) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 })
    }
    
    if (user.isActive) {
      return NextResponse.json({ success: false, error: 'Already active' }, { status: 400 })
    }
    
    // Restore
    await db.user.update({
      where: { id: userId },
      data: { isActive: true }
    })
    
    await createAuditLog({
      clientId: client.id,
      action: AuditAction.USER_RESTORED,
      username: user.username,
      request,
      status: 'success'
    })
    
    return NextResponse.json({ success: true, message: 'User restored' })
    
  } catch (error) {
    console.error('Restore user error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
