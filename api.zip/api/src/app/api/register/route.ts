/**
 * ============================================
 * API ENDPOINT: РЕГИСТРАЦИЯ ПОЛЬЗОВАТЕЛЕЙ
 * ============================================
 * 
 * Улучшенная версия с:
 * - Rate limiting
 * - Input validation
 * - Security headers
 * - Better error handling
 */

import { NextRequest, NextResponse } from 'next/server'
import { protectApiEnhanced, sanitizeString, validateUsername, validatePassword } from '@/lib/api-protection'
import { hashPassword } from '@/lib/auth'
import { db } from '@/lib/db'
import { createAuditLog, AuditAction } from '@/lib/audit'
import { sendWebhook, WebhookEvent } from '@/lib/webhook'

interface RegisterRequest {
  username: string
  password: string
}

function validateRegisterRequest(body: unknown): { 
  valid: boolean
  error?: string
  errors?: string[]
  data?: RegisterRequest 
} {
  if (!body || typeof body !== 'object') {
    return { valid: false, error: 'Request body is required' }
  }
  
  const { username, password } = body as Record<string, unknown>
  
  // Валидация username
  const usernameValidation = validateUsername(
    typeof username === 'string' ? username : ''
  )
  if (!usernameValidation.valid) {
    return { valid: false, error: usernameValidation.error }
  }
  
  // Валидация пароля
  const passwordValidation = validatePassword(
    typeof password === 'string' ? password : ''
  )
  if (!passwordValidation.valid) {
    return { valid: false, errors: passwordValidation.errors }
  }
  
  return { 
    valid: true, 
    data: { 
      username: sanitizeString(username as string), 
      password: password as string 
    } 
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()
  
  try {
    // ============================================
    // 1. ЗАЩИТА API (Rate Limit + API Key)
    // ============================================
    const protection = await protectApiEnhanced(request, 'auth')
    if (!protection.success) {
      return protection.response!
    }
    
    const client = protection.client!
    
    // ============================================
    // 2. ПАРСИНГ И ВАЛИДАЦИЯ
    // ============================================
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }
    
    const validation = validateRegisterRequest(body)
    if (!validation.valid) {
      return NextResponse.json(
        { 
          success: false, 
          error: validation.error,
          errors: validation.errors 
        },
        { status: 400 }
      )
    }
    
    const { username, password } = validation.data!
    
    // ============================================
    // 3. ПРОВЕРКА НА ДУБЛИКАТ
    // ============================================
    const existingUser = await db.user.findFirst({
      where: {
        username,
        clientId: client.id,
        isActive: true
      }
    })
    
    if (existingUser) {
      await createAuditLog({
        clientId: client.id,
        action: AuditAction.REGISTER_FAILED,
        username,
        request,
        status: 'failed',
        details: { reason: 'Username already exists' }
      })
      
      return NextResponse.json(
        { success: false, error: 'Username already exists' },
        { status: 409 }
      )
    }
    
    // ============================================
    // 4. ХЕШИРОВАНИЕ ПАРОЛЯ
    // ============================================
    const passwordHash = await hashPassword(password)
    
    // ============================================
    // 5. СОЗДАНИЕ ПОЛЬЗОВАТЕЛЯ
    // ============================================
    const user = await db.user.create({
      data: {
        username,
        passwordHash,
        clientId: client.id,
        isActive: true
      },
      select: {
        id: true,
        username: true,
        createdAt: true
      }
    })
    
    // ============================================
    // 6. ЛОГИРОВАНИЕ
    // ============================================
    await createAuditLog({
      clientId: client.id,
      action: AuditAction.REGISTER_SUCCESS,
      username,
      request,
      status: 'success'
    })
    
    // ============================================
    // 7. WEBHOOK (асинхронно)
    // ============================================
    sendWebhook(client.id, WebhookEvent.USER_REGISTERED, {
      userId: user.id,
      username: user.username,
      clientId: client.id,
      registeredAt: user.createdAt.toISOString()
    }).catch(console.error)
    
    // ============================================
    // 8. ОТВЕТ
    // ============================================
    console.log(`[API] Registration completed in ${Date.now() - startTime}ms`)
    
    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        createdAt: user.createdAt
      }
    }, { status: 201 })
    
  } catch (error) {
    console.error('Registration error:', error)
    
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
