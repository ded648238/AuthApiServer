/**
 * ============================================
 * API ENDPOINT: АВТОРИЗАЦИЯ ПОЛЬЗОВАТЕЛЕЙ
 * ============================================
 * 
 * Улучшенная версия с:
 * - Строгий rate limiting для защиты от брутфорса
 * - Constant-time comparison (через bcrypt)
 * - Подробное логирование
 */

import { NextRequest, NextResponse } from 'next/server'
import { protectApiEnhanced, sanitizeString } from '@/lib/api-protection'
import { verifyPassword, generateJWT } from '@/lib/auth'
import { db } from '@/lib/db'
import { createAuditLog, AuditAction } from '@/lib/audit'
import { sendWebhook, WebhookEvent } from '@/lib/webhook'

interface LoginRequest {
  username: string
  password: string
}

function validateLoginRequest(body: unknown): { 
  valid: boolean
  error?: string
  data?: LoginRequest 
} {
  if (!body || typeof body !== 'object') {
    return { valid: false, error: 'Request body is required' }
  }
  
  const { username, password } = body as Record<string, unknown>
  
  if (!username || typeof username !== 'string') {
    return { valid: false, error: 'Username is required' }
  }
  
  if (!password || typeof password !== 'string') {
    return { valid: false, error: 'Password is required' }
  }
  
  // Ограничиваем длину для предотвращения DoS
  if (username.length > 100 || password.length > 128) {
    return { valid: false, error: 'Invalid credentials' }
  }
  
  return { 
    valid: true, 
    data: { 
      username: sanitizeString(username), 
      password 
    } 
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()
  
  try {
    // ============================================
    // 1. ЗАЩИТА API (Строгий rate limiting!)
    // ============================================
    // Используем 'auth' тип для защиты от брутфорса
    // Это ограничивает до 5 попыток за 15 минут
    const protection = await protectApiEnhanced(request, 'auth')
    if (!protection.success) {
      return protection.response!
    }
    
    const client = protection.client!
    
    // ============================================
    // 2. ПАРСИНГ И ВАЛИДАЦИЯ
    // ============================================
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }
    
    const validation = validateLoginRequest(body)
    if (!validation.valid) {
      return NextResponse.json(
        { success: false, error: validation.error },
        { status: 400 }
      )
    }
    
    const { username, password } = validation.data!
    
    // ============================================
    // 3. ПОИСК ПОЛЬЗОВАТЕЛЯ
    // ============================================
    const user = await db.user.findFirst({
      where: {
        username,
        clientId: client.id,
        isActive: true
      }
    })
    
    // Используем одинаковое сообщение об ошибке
    // для предотвращения enumeration attacks
    const invalidCredentialsError = 'Invalid username or password'
    
    if (!user) {
      // Логируем неудачную попытку
      await createAuditLog({
        clientId: client.id,
        action: AuditAction.LOGIN_FAILED,
        username,
        request,
        status: 'failed',
        details: { reason: 'User not found' }
      })
      
      return NextResponse.json(
        { success: false, error: invalidCredentialsError },
        { status: 401 }
      )
    }
    
    // ============================================
    // 4. ПРОВЕРКА ПАРОЛЯ
    // ============================================
    // bcrypt.compare использует constant-time comparison
    // для защиты от timing attacks
    const isValidPassword = await verifyPassword(password, user.passwordHash)
    
    if (!isValidPassword) {
      await createAuditLog({
        clientId: client.id,
        action: AuditAction.LOGIN_FAILED,
        username,
        request,
        status: 'failed',
        details: { reason: 'Invalid password' }
      })
      
      return NextResponse.json(
        { success: false, error: invalidCredentialsError },
        { status: 401 }
      )
    }
    
    // ============================================
    // 5. ГЕНЕРАЦИЯ JWT
    // ============================================
    const token = generateJWT({
      userId: user.id,
      username: user.username,
      clientId: user.clientId
    })
    
    // ============================================
    // 6. ЛОГИРОВАНИЕ УСПЕХА
    // ============================================
    await createAuditLog({
      clientId: client.id,
      action: AuditAction.LOGIN_SUCCESS,
      username,
      request,
      status: 'success'
    })
    
    // ============================================
    // 7. WEBHOOK (асинхронно)
    // ============================================
    sendWebhook(client.id, WebhookEvent.USER_LOGIN, {
      userId: user.id,
      username: user.username,
      clientId: client.id,
      loginAt: new Date().toISOString()
    }).catch(console.error)
    
    // ============================================
    // 8. ОТВЕТ
    // ============================================
    console.log(`[API] Login completed in ${Date.now() - startTime}ms`)
    
    return NextResponse.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username
      },
      expiresIn: 3600 // 1 час
    })
    
  } catch (error) {
    console.error('Login error:', error)
    
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
