/**
 * ============================================
 * API ENDPOINT: УПРАВЛЕНИЕ API-КЛЮЧОМ
 * ============================================
 * 
 * GET /api/client/api-key - получить текущий API-ключ
 * POST /api/client/api-key - сгенерировать новый API-ключ
 */

import { NextRequest, NextResponse } from 'next/server'
import { verifyJWT, generateApiKey } from '@/lib/auth'
import { db } from '@/lib/db'
import { createAuditLog, AuditAction } from '@/lib/audit'

/**
 * Получить текущий API-ключ
 * Требуется авторизация через JWT токен в заголовке Authorization
 */
export async function GET(request: NextRequest) {
  try {
    // Проверяем JWT токен из заголовка Authorization
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Authorization header required' },
        { status: 401 }
      )
    }
    
    const token = authHeader.substring(7) // Убираем "Bearer "
    const payload = verifyJWT(token)
    
    if (!payload) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired token' },
        { status: 401 }
      )
    }
    
    // Получаем клиента
    const client = await db.client.findUnique({
      where: { id: payload.userId },
      select: {
        id: true,
        email: true,
        apiKey: true
      }
    })
    
    if (!client) {
      return NextResponse.json(
        { success: false, error: 'Client not found' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({
      success: true,
      apiKey: client.apiKey
    })
    
  } catch (error) {
    console.error('Get API key error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

/**
 * Сгенерировать новый API-ключ
 * ВНИМАНИЕ: Старый ключ перестанет работать!
 */
export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Authorization header required' },
        { status: 401 }
      )
    }
    
    const token = authHeader.substring(7)
    const payload = verifyJWT(token)
    
    if (!payload) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired token' },
        { status: 401 }
      )
    }
    
    // Генерируем новый API-ключ
    const newApiKey = generateApiKey()
    
    // Обновляем в базе данных
    const client = await db.client.update({
      where: { id: payload.userId },
      data: { apiKey: newApiKey },
      select: {
        id: true,
        email: true,
        apiKey: true
      }
    })
    
    // Логируем действие
    await createAuditLog({
      clientId: client.id,
      action: AuditAction.API_KEY_GENERATED,
      request,
      status: 'success'
    })
    
    return NextResponse.json({
      success: true,
      apiKey: client.apiKey,
      message: 'New API key generated. Previous key is now invalid.'
    })
    
  } catch (error) {
    console.error('Generate API key error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
