/**
 * API для входа разработчика
 */

import { NextRequest, NextResponse } from 'next/server'
import { verifyPassword, generateJWT } from '@/lib/auth'
import { db } from '@/lib/db'
import { applyRateLimit, addRateLimitHeaders, RATE_LIMIT_CONFIGS } from '@/lib/rate-limit'
import { validateEmail } from '@/lib/api-protection'

const INVALID_CREDENTIALS = 'Неверный email или пароль'

function sanitizeString(input: string): string {
  return input.substring(0, 100).trim()
}

export async function POST(request: NextRequest) {
  const rateLimit = applyRateLimit(request, 'auth')
  if (!rateLimit.success) {
    return rateLimit.response!
  }
  
  try {
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON' },
        { status: 400 }
      )
    }
    
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ success: false, error: 'Body required' }, { status: 400 })
    }
    
    const { email, password } = body as Record<string, unknown>
    
    const emailValidation = validateEmail(typeof email === 'string' ? email : '')
    if (!emailValidation.valid) {
      return NextResponse.json({ success: false, error: INVALID_CREDENTIALS }, { status: 401 })
    }
    
    if (!password || typeof password !== 'string') {
      return NextResponse.json({ success: false, error: INVALID_CREDENTIALS }, { status: 401 })
    }
    
    const client = await db.client.findUnique({
      where: { email: sanitizeString(email as string) }
    })
    
    if (!client) {
      return NextResponse.json({ success: false, error: INVALID_CREDENTIALS }, { status: 401 })
    }
    
    const isValidPassword = await verifyPassword(password, client.passwordHash)
    
    if (!isValidPassword) {
      return NextResponse.json({ success: false, error: INVALID_CREDENTIALS }, { status: 401 })
    }
    
    const token = generateJWT({
      userId: client.id,
      username: client.email,
      clientId: client.id
    })
    
    const response = NextResponse.json({
      success: true,
      token,
      client: {
        id: client.id,
        uid: client.uid,
        email: client.email,
        apiKey: client.apiKey,
        webhookUrl: client.webhookUrl,
        role: client.role
      },
      expiresIn: 3600
    })
    
    addRateLimitHeaders(
      response,
      'auth',
      rateLimit.remaining - 1,
      Date.now() + RATE_LIMIT_CONFIGS.auth.windowMs
    )
    
    return response
    
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
