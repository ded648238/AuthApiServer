/**
 * ============================================
 * API ENDPOINT: УПРАВЛЕНИЕ WEBHOOK URL
 * ============================================
 * 
 * GET /api/client/webhook - получить текущий webhook URL
 * PUT /api/client/webhook - обновить webhook URL
 */

import { NextRequest, NextResponse } from 'next/server'
import { verifyJWT } from '@/lib/auth'
import { db } from '@/lib/db'
import { createAuditLog, AuditAction } from '@/lib/audit'
import { validateWebhookUrl } from '@/lib/webhook'

/**
 * Получить текущий webhook URL
 */
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Authorization header required' },
        { status: 401 }
      )
    }
    
    const token = authHeader.substring(7)
    const payload = verifyJWT(token)
    
    if (!payload) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired token' },
        { status: 401 }
      )
    }
    
    const client = await db.client.findUnique({
      where: { id: payload.userId },
      select: {
        webhookUrl: true
      }
    })
    
    if (!client) {
      return NextResponse.json(
        { success: false, error: 'Client not found' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({
      success: true,
      webhookUrl: client.webhookUrl
    })
    
  } catch (error) {
    console.error('Get webhook error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

/**
 * Обновить webhook URL
 */
export async function PUT(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { success: false, error: 'Authorization header required' },
        { status: 401 }
      )
    }
    
    const token = authHeader.substring(7)
    const payload = verifyJWT(token)
    
    if (!payload) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired token' },
        { status: 401 }
      )
    }
    
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }
    
    const { webhookUrl } = body as Record<string, unknown>
    
    // Webhook URL может быть null (для удаления)
    if (webhookUrl !== null && typeof webhookUrl !== 'string') {
      return NextResponse.json(
        { success: false, error: 'webhookUrl must be a string or null' },
        { status: 400 }
      )
    }
    
    // Валидируем URL если он указан
    if (webhookUrl && !validateWebhookUrl(webhookUrl)) {
      return NextResponse.json(
        { success: false, error: 'Invalid webhook URL. Must start with http:// or https://' },
        { status: 400 }
      )
    }
    
    // Обновляем в базе данных
    const client = await db.client.update({
      where: { id: payload.userId },
      data: { webhookUrl },
      select: {
        id: true,
        webhookUrl: true
      }
    })
    
    // Логируем действие
    await createAuditLog({
      clientId: client.id,
      action: AuditAction.WEBHOOK_UPDATED,
      request,
      status: 'success',
      details: { webhookUrl }
    })
    
    return NextResponse.json({
      success: true,
      webhookUrl: client.webhookUrl,
      message: webhookUrl ? 'Webhook URL updated' : 'Webhook URL removed'
    })
    
  } catch (error) {
    console.error('Update webhook error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
