/**
 * API статистики
 */

import { NextRequest, NextResponse } from 'next/server'
import { verifyJWT } from '@/lib/auth'
import { db } from '@/lib/db'
import { AuditAction } from '@/lib/audit'

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }
    
    const token = authHeader.substring(7)
    const payload = verifyJWT(token)
    
    if (!payload) {
      return NextResponse.json({ success: false, error: 'Invalid token' }, { status: 401 })
    }
    
    const days = 30
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)
    
    // Получаем логи
    const logs = await db.auditLog.findMany({
      where: {
        clientId: payload.userId,
        createdAt: { gte: startDate }
      },
      orderBy: { createdAt: 'desc' }
    })
    
    // Подсчёт
    const stats = {
      totalEvents: logs.length,
      successfulLogins: logs.filter(l => l.action === AuditAction.LOGIN_SUCCESS).length,
      failedLogins: logs.filter(l => l.action === AuditAction.LOGIN_FAILED).length,
      registrations: logs.filter(l => l.action === AuditAction.REGISTER_SUCCESS).length,
      
      // Группировка по дням
      eventsByDay: groupByDay(logs),
      
      // Последние события
      recentEvents: logs.slice(0, 10)
    }
    
    return NextResponse.json({ success: true, stats })
    
  } catch (error) {
    console.error('Stats error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

function groupByDay(logs: { createdAt: Date; action: string; status: string }[]) {
  const byDay: Record<string, { date: string; total: number; success: number; failed: number }> = {}
  
  for (const log of logs) {
    const date = log.createdAt.toISOString().split('T')[0]
    
    if (!byDay[date]) {
      byDay[date] = { date, total: 0, success: 0, failed: 0 }
    }
    
    byDay[date].total++
    if (log.status === 'success') {
      byDay[date].success++
    } else {
      byDay[date].failed++
    }
  }
  
  return Object.values(byDay).sort((a, b) => a.date.localeCompare(b.date))
}
