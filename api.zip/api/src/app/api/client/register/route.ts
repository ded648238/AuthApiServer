/**
 * API для регистрации разработчика с UID
 */

import { NextResponse } from 'next/server'
import { hashPassword, generateApiKey } from '@/lib/auth'
import { db } from '@/lib/db'
import { applyRateLimit, addRateLimitHeaders, RATE_LIMIT_CONFIGS } from '@/lib/rate-limit'
import { validateEmail, validatePassword, sanitizeString } from '@/lib/api-protection'

const ADMIN_EMAIL = 'ded648238@gmail.com'
const ADMIN_PASSWORD = 'Login1234556'

interface ClientRegisterRequest {
  email: string
  password: string
}

function validateRequest(body: unknown): { 
  valid: boolean
  error?: string
  errors?: string[]
  data?: ClientRegisterRequest 
} {
  if (!body || typeof body !== 'object') {
    return { valid: false, error: 'Request body is required' }
  }
  
  const { email, password } = body as Record<string, unknown>
  
  const emailValidation = validateEmail(typeof email === 'string' ? email : '')
  if (!emailValidation.valid) {
    return { valid: false, error: emailValidation.error }
  }
  
  const passwordValidation = validatePassword(typeof password === 'string' ? password : '')
  if (!passwordValidation.valid) {
    return { valid: false, errors: passwordValidation.errors }
  }
  
  const pwd = password as string
  const additionalErrors: string[] = []
  
  if (!/[A-Z]/.test(pwd)) {
    additionalErrors.push('Нужна заглавная буква')
  }
  
  if (!/[a-z]/.test(pwd)) {
    additionalErrors.push('Нужна строчная буква')
  }
  
  if (!/[0-9]/.test(pwd)) {
    additionalErrors.push('Нужна цифра')
  }
  
  if (additionalErrors.length > 0) {
    return { valid: false, errors: [...(passwordValidation.errors || []), ...additionalErrors] }
  }
  
  return { 
    valid: true, 
    data: { 
      email: sanitizeString(email as string), 
      password: pwd 
    } 
  }
}

export async function POST(request: Request) {
  const rateLimit = applyRateLimit(request, 'auth')
  if (!rateLimit.success) {
    return rateLimit.response!
  }
  
  try {
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }
    
    const validation = validateRequest(body)
    if (!validation.valid) {
      return NextResponse.json(
        { 
          success: false, 
          error: validation.error,
          errors: validation.errors 
        },
        { status: 400 }
      )
    }
    
    const { email, password } = validation.data!
    
    // Проверяем существование email
    const existingClient = await db.client.findUnique({
      where: { email }
    })
    
    if (existingClient) {
      return NextResponse.json(
        { success: false, error: 'Email уже зарегистрирован' },
        { status: 409 }
      )
    }
    
    // Получаем максимальный UID и добавляем 1
    const maxUidResult = await db.client.findFirst({
      orderBy: { uid: 'desc' },
      select: { uid: true }
    })
    
    const nextUid = (maxUidResult?.uid || 0) + 1
    
    // Хешируем пароль
    const passwordHash = await hashPassword(password)
    
    // Генерируем API-ключ
    const apiKey = generateApiKey()
    
    // Создаём клиента с UID
    const client = await db.client.create({
      data: {
        uid: nextUid,
        email,
        passwordHash,
        apiKey
      },
      select: {
        id: true,
        uid: true,
        email: true,
        apiKey: true,
        createdAt: true
      }
    })
    
    const response = NextResponse.json({
      success: true,
      client: {
        id: client.id,
        uid: client.uid,
        email: client.email,
        apiKey: client.apiKey,
        createdAt: client.createdAt
      },
      message: 'Аккаунт создан! Ваш UID: ' + client.uid
    }, { status: 201 })
    
    addRateLimitHeaders(
      response,
      'auth',
      rateLimit.remaining - 1,
      Date.now() + RATE_LIMIT_CONFIGS.auth.windowMs
    )
    
    return response
    
  } catch (error) {
    console.error('Client registration error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// GET для создания админа если его нет
export async function GET() {
  try {
    // Проверяем существование админа
    const existingAdmin = await db.client.findUnique({
      where: { email: ADMIN_EMAIL }
    })
    
    if (existingAdmin) {
      // Обновляем роль на admin если нужно
      if (existingAdmin.role !== 'admin') {
        await db.client.update({
          where: { email: ADMIN_EMAIL },
          data: { role: 'admin' }
        })
      }
      
      return NextResponse.json({
        success: true,
        message: 'Admin already exists',
        credentials: {
          email: ADMIN_EMAIL,
          uid: existingAdmin.uid,
          apiKey: existingAdmin.apiKey
        }
      })
    }
    
    // Создаём админа с UID = 1
    const passwordHash = await hashPassword(ADMIN_PASSWORD)
    const apiKey = generateApiKey()
    
    const admin = await db.client.create({
      data: {
        uid: 1,
        email: ADMIN_EMAIL,
        passwordHash,
        apiKey,
        role: 'admin'
      }
    })
    
    return NextResponse.json({
      success: true,
      message: 'Admin created successfully',
      credentials: {
        email: ADMIN_EMAIL,
        password: ADMIN_PASSWORD,
        uid: admin.uid,
        apiKey: admin.apiKey
      }
    })
    
  } catch (error) {
    console.error('Seed error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to create admin'
    }, { status: 500 })
  }
}
