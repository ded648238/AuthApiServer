/**
 * ============================================
 * API ENDPOINT: ЗАПРОС НА СБРОС ПАРОЛЯ
 * ============================================
 * 
 * POST /api/password-reset/request
 * 
 * Генерирует токен для сброса пароля и отправляет
 * его на email разработчика (в демо - возвращает токен).
 * 
 * В реальном проекте здесь была бы отправка email.
 */

import { NextRequest, NextResponse } from 'next/server'
import { generatePasswordResetToken } from '@/lib/auth'
import { db } from '@/lib/db'
import { createAuditLog, AuditAction } from '@/lib/audit'

interface ResetRequestRequest {
  email: string
}

function validateRequest(body: unknown): { valid: boolean; error?: string; data?: ResetRequestRequest } {
  if (!body || typeof body !== 'object') {
    return { valid: false, error: 'Request body is required' }
  }
  
  const { email } = body as Record<string, unknown>
  
  if (!email || typeof email !== 'string') {
    return { valid: false, error: 'Email is required' }
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email)) {
    return { valid: false, error: 'Invalid email format' }
  }
  
  return { valid: true, data: { email } }
}

export async function POST(request: NextRequest) {
  try {
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }
    
    const validation = validateRequest(body)
    if (!validation.valid) {
      return NextResponse.json(
        { success: false, error: validation.error },
        { status: 400 }
      )
    }
    
    const { email } = validation.data!
    
    // Ищем клиента по email
    const client = await db.client.findUnique({
      where: { email }
    })
    
    // В целях безопасности не раскрываем, существует ли email
    if (!client) {
      // Возвращаем успешный ответ, но не создаём токен
      return NextResponse.json({
        success: true,
        message: 'If the email exists, a reset link has been sent.'
      })
    }
    
    // Генерируем токен сброса
    const { token, expiresAt } = generatePasswordResetToken()
    
    // Сохраняем токен в базе данных
    await db.passwordResetToken.create({
      data: {
        clientId: client.id,
        token,
        expiresAt
      }
    })
    
    // Логируем запрос
    await createAuditLog({
      clientId: client.id,
      action: AuditAction.PASSWORD_RESET_REQUEST,
      request,
      status: 'success'
    })
    
    // В реальном проекте здесь отправляли бы email
    // Для демо возвращаем токен в ответе
    return NextResponse.json({
      success: true,
      message: 'If the email exists, a reset link has been sent.',
      // В демо возвращаем токен для тестирования
      // В продакшене уберите это поле!
      _demo_token: token,
      _demo_expiresAt: expiresAt
    })
    
  } catch (error) {
    console.error('Password reset request error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
