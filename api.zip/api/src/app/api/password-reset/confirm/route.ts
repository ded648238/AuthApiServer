/**
 * ============================================
 * API ENDPOINT: ПОДТВЕРЖДЕНИЕ СБРОСА ПАРОЛЯ
 * ============================================
 * 
 * POST /api/password-reset/confirm
 * 
 * Проверяет токен сброса и устанавливает новый пароль.
 */

import { NextRequest, NextResponse } from 'next/server'
import { hashPassword } from '@/lib/auth'
import { db } from '@/lib/db'
import { createAuditLog, AuditAction } from '@/lib/audit'

interface ResetConfirmRequest {
  token: string
  newPassword: string
}

function validateRequest(body: unknown): { valid: boolean; error?: string; data?: ResetConfirmRequest } {
  if (!body || typeof body !== 'object') {
    return { valid: false, error: 'Request body is required' }
  }
  
  const { token, newPassword } = body as Record<string, unknown>
  
  if (!token || typeof token !== 'string') {
    return { valid: false, error: 'Token is required' }
  }
  
  if (!newPassword || typeof newPassword !== 'string') {
    return { valid: false, error: 'New password is required' }
  }
  
  if (newPassword.length < 8) {
    return { valid: false, error: 'Password must be at least 8 characters' }
  }
  
  return { valid: true, data: { token, newPassword } }
}

export async function POST(request: NextRequest) {
  try {
    let body: unknown
    try {
      body = await request.json()
    } catch {
      return NextResponse.json(
        { success: false, error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }
    
    const validation = validateRequest(body)
    if (!validation.valid) {
      return NextResponse.json(
        { success: false, error: validation.error },
        { status: 400 }
      )
    }
    
    const { token, newPassword } = validation.data!
    
    // Ищем токен в базе данных
    const resetToken = await db.passwordResetToken.findUnique({
      where: { token },
      include: { client: true }
    })
    
    if (!resetToken) {
      return NextResponse.json(
        { success: false, error: 'Invalid or expired token' },
        { status: 400 }
      )
    }
    
    // Проверяем, не истёк ли токен
    if (resetToken.expiresAt < new Date()) {
      await createAuditLog({
        clientId: resetToken.clientId,
        action: AuditAction.PASSWORD_RESET_FAILED,
        request,
        status: 'failed',
        details: { reason: 'Token expired' }
      })
      
      return NextResponse.json(
        { success: false, error: 'Token has expired. Please request a new one.' },
        { status: 400 }
      )
    }
    
    // Проверяем, не был ли токен уже использован
    if (resetToken.used) {
      await createAuditLog({
        clientId: resetToken.clientId,
        action: AuditAction.PASSWORD_RESET_FAILED,
        request,
        status: 'failed',
        details: { reason: 'Token already used' }
      })
      
      return NextResponse.json(
        { success: false, error: 'Token has already been used.' },
        { status: 400 }
      )
    }
    
    // Хешируем новый пароль
    const passwordHash = await hashPassword(newPassword)
    
    // Обновляем пароль и помечаем токен как использованный
    await db.$transaction([
      db.client.update({
        where: { id: resetToken.clientId },
        data: { passwordHash }
      }),
      db.passwordResetToken.update({
        where: { id: resetToken.id },
        data: { used: true }
      })
    ])
    
    // Логируем успешный сброс
    await createAuditLog({
      clientId: resetToken.clientId,
      action: AuditAction.PASSWORD_RESET_SUCCESS,
      request,
      status: 'success'
    })
    
    return NextResponse.json({
      success: true,
      message: 'Password has been reset successfully. You can now log in with your new password.'
    })
    
  } catch (error) {
    console.error('Password reset confirm error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
