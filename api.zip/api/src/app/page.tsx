'use client'

/**
 * ============================================
 * AUTH SERVICE - КОСМИЧЕСКАЯ ВЕРСИЯ v2
 * ============================================
 */

import { useState, useEffect, useMemo, useCallback } from 'react'
import { useAuthStore } from '@/store/auth-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle 
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Key, Shield, Users, Webhook, BookOpen, LogOut, Copy, RefreshCw,
  CheckCircle, XCircle, AlertTriangle, Trash2, RotateCcw, Eye, EyeOff,
  BarChart3, Globe, Lock, Sparkles, ArrowRight, Zap, Search, Download,
  Clock, Activity, User, Camera, Award, Star, Database, Globe2, Rocket,
  Sun, Moon, Hash, Trash
} from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

// ============================================
// THEME CONTEXT
// ============================================
const THEME_KEY = 'auth-service-theme'

function useTheme() {
  const [theme, setTheme] = useState<'dark' | 'light' | 'green'>(() => {
    if (typeof window !== 'undefined') {
      return (localStorage.getItem(THEME_KEY) as 'dark' | 'light' | 'green') || 'dark'
    }
    return 'dark'
  })
  
  const toggleTheme = useCallback(() => {
    setTheme(prev => {
      const next = prev === 'dark' ? 'light' : prev === 'light' ? 'green' : 'dark'
      localStorage.setItem(THEME_KEY, next)
      return next
    })
  }, [])
  
  return { theme, toggleTheme }
}

// ============================================
// TOAST
// ============================================
interface ToastData {
  id: string
  type: 'success' | 'error' | 'info'
  message: string
}

function ToastContainer({ toasts, onRemove }: { toasts: ToastData[], onRemove: (id: string) => void }) {
  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      {toasts.map(toast => (
        <div
          key={toast.id}
          className="animate-fade-in flex items-center gap-3 px-4 py-3 rounded-lg border min-w-[240px] text-sm"
          style={{
            background: toast.type === 'success' ? 'rgba(16, 185, 129, 0.1)' : 
                       toast.type === 'error' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(59, 130, 246, 0.1)',
            borderColor: toast.type === 'success' ? 'rgba(16, 185, 129, 0.3)' : 
                         toast.type === 'error' ? 'rgba(239, 68, 68, 0.3)' : 'rgba(59, 130, 246, 0.3)',
            color: toast.type === 'success' ? '#6ee7b7' : toast.type === 'error' ? '#fca5a5' : '#93c5fd'
          }}
        >
          {toast.type === 'success' && <CheckCircle className="w-4 h-4 flex-shrink-0" />}
          {toast.type === 'error' && <XCircle className="w-4 h-4 flex-shrink-0" />}
          {toast.type === 'info' && <Star className="w-4 h-4 flex-shrink-0" />}
          <span className="flex-1">{toast.message}</span>
          <button onClick={() => onRemove(toast.id)} className="opacity-50 hover:opacity-100">
            <XCircle className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  )
}

// ============================================
// COSMIC BACKGROUND
// ============================================
function CosmicBackground({ theme }: { theme: 'dark' | 'light' | 'green' }) {
  return (
    <>
      <div className="cosmos-bg" />
      {theme === 'dark' && <div className="stars" />}
    </>
  )
}

// ============================================
// LOGIN FORM
// ============================================
function LoginForm({ onToggle, onToast }: { onToggle: () => void, onToast: (type: ToastData['type'], msg: string) => void }) {
  const { setAuth, setLoading, setError, isLoading, error } = useAuthStore()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const res = await fetch('/api/client/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      })
      const data = await res.json()
      if (!data.success) {
        setError(data.error)
        onToast('error', data.error)
        return
      }
      onToast('success', `Добро пожаловать, UID: ${data.client.uid}!`)
      setAuth(data.client, data.token)
    } catch {
      setError('Ошибка соединения')
      onToast('error', 'Ошибка соединения')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full max-w-sm mx-auto animate-fade-in">
      <div className="glass-card p-6 text-center">
        <div className="w-12 h-12 mx-auto mb-3 rounded-xl gradient-icon animate-pulse-glow">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-xl font-bold gradient-text mb-1">Auth Service</h1>
        <p className="text-xs text-[var(--muted-foreground)] mb-5">Войдите в панель</p>

        <form onSubmit={handleSubmit} className="space-y-3">
          {error && (
            <Alert className="bg-red-500/10 border-red-500/20 text-red-300 py-2">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-xs">{error}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-1.5 text-left">
            <Label className="text-xs text-[var(--muted-foreground)]">Email</Label>
            <Input
              type="email"
              placeholder="developer@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="glass-input h-10 rounded-lg text-sm"
              required
            />
          </div>

          <div className="space-y-1.5 text-left">
            <Label className="text-xs text-[var(--muted-foreground)]">Пароль</Label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="glass-input h-10 pr-10 rounded-lg text-sm"
                required
              />
              <button
                type="button"
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] hover:text-white"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <Button type="submit" className="w-full h-10 glass-button rounded-lg text-white text-sm" disabled={isLoading}>
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Вход...</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4" />
                <span>Войти</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            )}
          </Button>

          <p className="text-xs text-[var(--muted-foreground)]">
            Нет аккаунта?{' '}
            <button type="button" className="text-[var(--primary)] hover:underline" onClick={onToggle}>
              Зарегистрироваться
            </button>
          </p>
        </form>
      </div>
    </div>
  )
}

// ============================================
// REGISTER FORM
// ============================================
function RegisterForm({ onToggle, onToast }: { onToggle: () => void, onToast: (type: ToastData['type'], msg: string) => void }) {
  const { setAuth, setLoading, setError, isLoading, error } = useAuthStore()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)

  const checks = {
    length: password.length >= 8,
    upper: /[A-Z]/.test(password),
    lower: /[a-z]/.test(password),
    number: /[0-9]/.test(password)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (password !== confirmPassword) {
      setError('Пароли не совпадают')
      onToast('error', 'Пароли не совпадают')
      return
    }
    if (!Object.values(checks).every(Boolean)) {
      setError('Пароль не соответствует требованиям')
      return
    }
    setLoading(true)
    setError(null)

    try {
      const res = await fetch('/api/client/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      })
      const data = await res.json()
      if (!data.success) {
        setError(data.error || data.errors?.join(', '))
        onToast('error', data.error || 'Ошибка')
        return
      }
      
      onToast('success', `Аккаунт создан! Ваш UID: ${data.client.uid}`)
      
      // Auto login
      const loginRes = await fetch('/api/client/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      })
      const loginData = await loginRes.json()
      if (loginData.success) {
        setAuth(loginData.client, loginData.token)
      }
    } catch {
      setError('Ошибка соединения')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full max-w-sm mx-auto animate-fade-in">
      <div className="glass-card p-6 text-center">
        <div className="w-12 h-12 mx-auto mb-3 rounded-xl" style={{ background: 'linear-gradient(135deg, #10b981, #06b6d4)', display: 'flex', alignItems: 'center', justifyContentContent: 'center' }}>
          <Sparkles className="w-6 h-6 text-white" style={{ margin: 'auto' }} />
        </div>
        <h1 className="text-xl font-bold gradient-text mb-1">Регистрация</h1>
        <p className="text-xs text-[var(--muted-foreground)] mb-5">Создайте аккаунт</p>

        <form onSubmit={handleSubmit} className="space-y-3">
          {error && <Alert className="bg-red-500/10 border-red-500/20 text-red-300 py-2 text-xs"><AlertTriangle className="h-4 w-4" /><AlertDescription>{error}</AlertDescription></Alert>}

          <div className="space-y-1.5 text-left">
            <Label className="text-xs text-[var(--muted-foreground)]">Email</Label>
            <Input type="email" placeholder="developer@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="glass-input h-10 rounded-lg text-sm" required />
          </div>

          <div className="space-y-1.5 text-left">
            <Label className="text-xs text-[var(--muted-foreground)]">Пароль</Label>
            <div className="relative">
              <Input type={showPassword ? 'text' : 'password'} placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} className="glass-input h-10 pr-10 rounded-lg text-sm" required />
              <button type="button" className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)] hover:text-white" onClick={() => setShowPassword(!showPassword)}>
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {password && (
              <div className="grid grid-cols-2 gap-1 mt-1.5">
                {Object.entries({ length: '8+ символов', upper: 'Заглавная', lower: 'Строчная', number: 'Цифра' }).map(([k, v]) => (
                  <span key={k} className={`text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1 ${checks[k as keyof typeof checks] ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
                    {checks[k as keyof typeof checks] ? <CheckCircle className="w-2.5 h-2.5" /> : <XCircle className="w-2.5 h-2.5" />} {v}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-1.5 text-left">
            <Label className="text-xs text-[var(--muted-foreground)]">Подтвердите</Label>
            <Input type="password" placeholder="••••••••" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="glass-input h-10 rounded-lg text-sm" required />
          </div>

          <Button type="submit" className="w-full h-10 rounded-lg text-white text-sm" style={{ background: 'linear-gradient(135deg, #10b981, #06b6d4)' }} disabled={isLoading || !Object.values(checks).every(Boolean)}>
            {isLoading ? <div className="flex items-center gap-2"><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /><span>Создание...</span></div> : <div className="flex items-center gap-2"><Zap className="w-4 h-4" /><span>Создать</span></div>}
          </Button>

          <p className="text-xs text-[var(--muted-foreground)]">
            Уже есть аккаунт? <button type="button" className="text-[var(--primary)] hover:underline" onClick={onToggle}>Войти</button>
          </p>
        </form>
      </div>
    </div>
  )
}

// ============================================
// DASHBOARD
// ============================================
function Dashboard({ onToast, theme, toggleTheme }: { 
  onToast: (type: ToastData['type'], msg: string) => void,
  theme: 'dark' | 'light' | 'green',
  toggleTheme: () => void
}) {
  const { client, token, clearAuth, updateClient } = useAuthStore()
  const [showApiKey, setShowApiKey] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)
  const [webhookUrl, setWebhookUrl] = useState(client?.webhookUrl || '')
  const [stats, setStats] = useState<any>(null)
  const [users, setUsers] = useState<any[]>([])
  const [isLoadingKey, setIsLoadingKey] = useState(false)
  const [isLoadingWebhook, setIsLoadingWebhook] = useState(false)
  const [isLoadingUsers, setIsLoadingUsers] = useState(false)
  
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'deleted'>('all')
  
  const [confirmDialog, setConfirmDialog] = useState<{ open: boolean, action: () => void, title: string }>({ open: false, action: () => {}, title: '' })
  
  const [currentTime, setCurrentTime] = useState(new Date())

  const [avatar, setAvatar] = useState<string | null>(() => {
    if (typeof window !== 'undefined' && client?.id) {
      return localStorage.getItem(`avatar-${client.id}`)
    }
    return null
  })

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    async function loadData() {
      if (token) {
        try {
          const res = await fetch('/api/client/stats', { headers: { 'Authorization': `Bearer ${token}` } })
          const data = await res.json()
          if (data.success) setStats(data.stats)
        } catch {}
        
        setIsLoadingUsers(true)
        try {
          const res = await fetch('/api/users?includeDeleted=true', { headers: { 'x-api-key': client?.apiKey || '' } })
          const data = await res.json()
          if (data.success) setUsers(data.users)
        } catch {}
        setIsLoadingUsers(false)
      }
    }
    loadData()
  }, [token, client?.apiKey])

  const filteredUsers = useMemo(() => {
    let result = users
    if (searchQuery) result = result.filter(u => u.username.toLowerCase().includes(searchQuery.toLowerCase()))
    if (statusFilter !== 'all') result = result.filter(u => statusFilter === 'active' ? u.isActive : !u.isActive)
    return result
  }, [users, searchQuery, statusFilter])

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(label)
      onToast('success', `${label} скопирован!`)
      setTimeout(() => setCopied(null), 2000)
    } catch {
      onToast('error', 'Ошибка копирования')
    }
  }

  const regenerateApiKey = () => {
    setConfirmDialog({
      open: true,
      title: 'Сгенерировать новый ключ?',
      action: async () => {
        setIsLoadingKey(true)
        try {
          const res = await fetch('/api/client/api-key', { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } })
          const data = await res.json()
          if (data.success) {
            updateClient({ apiKey: data.apiKey })
            onToast('success', 'Новый ключ сгенерирован!')
          }
        } catch {}
        setIsLoadingKey(false)
      }
    })
  }

  const saveWebhook = async () => {
    setIsLoadingWebhook(true)
    try {
      await fetch('/api/client/webhook', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ webhookUrl: webhookUrl || null })
      })
      updateClient({ webhookUrl: webhookUrl || null })
      onToast('success', webhookUrl ? 'Webhook сохранён!' : 'Webhook удалён!')
    } catch {}
    setIsLoadingWebhook(false)
  }

  const deleteUser = (userId: string, username: string) => {
    setConfirmDialog({
      open: true,
      title: `Удалить "${username}"?`,
      action: async () => {
        try {
          await fetch('/api/users', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json', 'x-api-key': client?.apiKey || '' },
            body: JSON.stringify({ userId })
          })
          onToast('success', 'Пользователь удалён')
          const res = await fetch('/api/users?includeDeleted=true', { headers: { 'x-api-key': client?.apiKey || '' } })
          const data = await res.json()
          if (data.success) setUsers(data.users)
        } catch {}
      }
    })
  }

  const restoreUser = async (userId: string, username: string) => {
    try {
      await fetch('/api/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-api-key': client?.apiKey || '' },
        body: JSON.stringify({ userId })
      })
      onToast('success', 'Пользователь восстановлен')
      const res = await fetch('/api/users?includeDeleted=true', { headers: { 'x-api-key': client?.apiKey || '' } })
      const data = await res.json()
      if (data.success) setUsers(data.users)
    } catch {}
  }

  const exportData = (type: 'users' | 'audit') => {
    const data = type === 'users' ? users : (stats?.recentEvents || [])
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `${type}_export.json`
    a.click()
    onToast('success', `Экспортировано ${data.length} записей`)
  }

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        const base64 = reader.result as string
        setAvatar(base64)
        if (client?.id) localStorage.setItem(`avatar-${client.id}`, base64)
        onToast('success', 'Аватар обновлён!')
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b" style={{ background: 'var(--card)', borderColor: 'var(--border)' }}>
        <div className="container mx-auto px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg gradient-icon animate-pulse-glow">
              <Shield className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-sm gradient-text">Auth Service</h1>
              <p className="text-[10px] text-[var(--muted-foreground)]">{currentTime.toLocaleTimeString('ru-RU')}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="w-8 h-8 rounded-lg flex items-center justify-center glass-input hover:bg-white/10 transition-colors"
              title={theme === 'dark' ? 'Тёмная тема' : theme === 'light' ? 'Светлая тема' : 'Зелёная тема'}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-yellow-400" /> : theme === 'light' ? <Moon className="w-4 h-4 text-purple-400" /> : <Star className="w-4 h-4 text-green-400" />}
            </button>
            
            <div className="avatar cursor-pointer" onClick={() => document.getElementById('avatar-upload')?.click()}>
              {avatar ? <img src={avatar} alt="Avatar" /> : client?.email?.[0].toUpperCase()}
            </div>
            <input id="avatar-upload" type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
            <Button variant="ghost" size="sm" onClick={clearAuth} className="glass-input text-xs h-8">
              <LogOut className="w-3.5 h-3.5 mr-1" /> Выйти
            </Button>
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="container mx-auto px-4 py-4 flex-1">
        <Tabs defaultValue="dashboard" className="space-y-4">
          <TabsList className="glass grid w-full max-w-xl mx-auto p-1 h-auto" style={{ gridTemplateColumns: client?.role === 'admin' ? 'repeat(7, 1fr)' : 'repeat(6, 1fr)' }}>
            {[
              { value: 'dashboard', icon: BarChart3, label: 'Главная' },
              { value: 'api', icon: Key, label: 'API' },
              { value: 'users', icon: Users, label: 'Юзеры' },
              { value: 'webhooks', icon: Webhook, label: 'Hooks' },
              { value: 'profile', icon: User, label: 'Профиль' },
              { value: 'docs', icon: BookOpen, label: 'Docs' },
              ...(client?.role === 'admin' ? [{ value: 'admin', icon: Shield, label: 'Админ' }] : [])
            ].map(({ value, icon: Icon, label }) => (
              <TabsTrigger key={value} value={value} className={`data-[state=active]:bg-white/10 rounded-lg py-1.5 text-xs ${value === 'admin' ? 'data-[state=active]:bg-red-500/20' : ''}`}>
                <Icon className={`w-3.5 h-3.5 sm:mr-1 ${value === 'admin' ? 'text-red-400' : ''}`} />
                <span className="hidden sm:inline">{label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="animate-fade-in space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'Пользователей', value: stats?.totalUsers || 0, icon: Users },
                { label: 'Событий', value: stats?.totalEvents || 0, icon: Activity },
                { label: 'Успешных', value: stats?.successfulLogins || 0, icon: CheckCircle },
                { label: 'Ошибок', value: stats?.failedLogins || 0, icon: XCircle }
              ].map(({ label, value, icon: Icon }) => (
                <div key={label} className="stat-card">
                  <div className="flex items-center gap-2 mb-1.5">
                    <Icon className="w-3.5 h-3.5 text-[var(--primary)]" />
                    <span className="text-xs text-[var(--muted-foreground)]">{label}</span>
                  </div>
                  <div className="text-xl font-bold">{value}</div>
                </div>
              ))}
            </div>

            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 flex items-center gap-2 text-sm"><Zap className="w-4 h-4 text-yellow-400" /> Быстрые действия</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <Button variant="outline" size="sm" className="glass-input justify-start h-8 text-xs" onClick={() => copyToClipboard(client?.apiKey || '', 'API-ключ')}>
                  <Copy className="w-3.5 h-3.5 mr-1.5" /> Копировать ключ
                </Button>
                <Button variant="outline" size="sm" className="glass-input justify-start h-8 text-xs" onClick={() => exportData('users')}>
                  <Download className="w-3.5 h-3.5 mr-1.5" /> Экспорт
                </Button>
                <Button variant="outline" size="sm" className="glass-input justify-start h-8 text-xs" onClick={async () => {
                  const res = await fetch('/api/client/stats', { headers: { 'Authorization': `Bearer ${token}` } })
                  const data = await res.json()
                  if (data.success) setStats(data.stats)
                  onToast('info', 'Обновлено')
                }}>
                  <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Обновить
                </Button>
                <Button variant="outline" size="sm" className="glass-input justify-start h-8 text-xs" onClick={() => onToast('info', 'Система OK ✓')}>
                  <CheckCircle className="w-3.5 h-3.5 mr-1.5 text-green-400" /> Статус
                </Button>
              </div>
            </div>

            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 text-sm">Активность</h3>
              {stats?.eventsByDay?.length > 0 ? (
                <div className="h-40">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.eventsByDay.slice(-7)}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="date" tickFormatter={(v) => v.slice(5)} stroke="var(--muted-foreground)" fontSize={10} />
                      <YAxis stroke="var(--muted-foreground)" fontSize={10} />
                      <Tooltip contentStyle={{ background: 'var(--popover)', border: '1px solid var(--border)', borderRadius: '8px' }} />
                      <Bar dataKey="success" fill="var(--chart-1)" radius={[3, 3, 0, 0]} />
                      <Bar dataKey="failed" fill="var(--destructive)" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : <p className="text-[var(--muted-foreground)] text-center py-6 text-sm">Нет данных</p>}
            </div>

            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 text-sm">Последние события</h3>
              {stats?.recentEvents?.length > 0 ? (
                <div className="space-y-1.5 max-h-48 overflow-y-auto">
                  {stats.recentEvents.slice(0, 8).map((event: any, i: number) => (
                    <div key={i} className="flex items-center gap-2.5 p-2 rounded-lg" style={{ background: 'var(--muted)' }}>
                      {event.status === 'success' ? <CheckCircle className="w-3.5 h-3.5 text-green-400" /> : <XCircle className="w-3.5 h-3.5 text-red-400" />}
                      <div className="flex-1 min-w-0">
                        <div className="text-xs truncate">{event.action}</div>
                        {event.username && <div className="text-[10px] text-[var(--muted-foreground)]">{event.username}</div>}
                      </div>
                      <div className="text-[10px] text-[var(--muted-foreground)]">{new Date(event.createdAt).toLocaleTimeString('ru-RU')}</div>
                    </div>
                  ))}
                </div>
              ) : <p className="text-[var(--muted-foreground)] text-center py-4 text-sm">Нет событий</p>}
            </div>
          </TabsContent>

          {/* API */}
          <TabsContent value="api" className="animate-fade-in space-y-4">
            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 flex items-center gap-2 text-sm"><Key className="w-4 h-4 text-[var(--primary)]" /> API-ключ</h3>
              <div className="rounded-lg p-2.5 mb-3 font-mono text-xs break-all relative" style={{ background: 'var(--muted)' }}>
                {showApiKey ? client?.apiKey : '•••••••••••••••••••••••••••••••••••••••••••••••••••••'}
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setShowApiKey(!showApiKey)}>
                    {showApiKey ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </Button>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => copyToClipboard(client?.apiKey || '', 'API-ключ')}>
                    {copied === 'API-ключ' ? <CheckCircle className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                  </Button>
                </div>
              </div>
              <div className="flex gap-2">
                <Button className="glass-button flex-1 h-9 text-xs" onClick={() => copyToClipboard(client?.apiKey || '', 'API-ключ')}>
                  <Copy className="w-3.5 h-3.5 mr-1.5" /> Копировать
                </Button>
                <Button variant="destructive" className="h-9 text-xs" onClick={regenerateApiKey} disabled={isLoadingKey}>
                  <RefreshCw className={`w-3.5 h-3.5 mr-1.5 ${isLoadingKey ? 'animate-spin' : ''}`} /> Новый
                </Button>
              </div>
            </div>

            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 text-sm">Информация</h3>
              <div className="grid grid-cols-2 gap-2.5">
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5 flex items-center gap-1"><Hash className="w-2.5 h-2.5" /> UID</div>
                  <div className="uid-badge">#{client?.uid}</div>
                </div>
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5">Email</div>
                  <div className="text-xs truncate">{client?.email}</div>
                </div>
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5">Роль</div>
                  <Badge className="bg-[var(--primary)]/15 text-[var(--primary)] text-[10px]">Developer</Badge>
                </div>
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5">Статус</div>
                  <Badge className="bg-green-500/15 text-green-400 text-[10px]">Активен</Badge>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Users */}
          <TabsContent value="users" className="animate-fade-in space-y-4">
            <div className="glass-card p-4">
              <div className="flex flex-wrap items-center justify-between gap-2.5 mb-3">
                <h3 className="font-medium flex items-center gap-2 text-sm"><Users className="w-4 h-4 text-[var(--primary)]" /> Пользователи <Badge variant="outline" className="text-[10px]">{filteredUsers.length}</Badge></h3>
                <div className="flex items-center gap-1.5">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-[var(--muted-foreground)]" />
                    <Input placeholder="Поиск..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="glass-input pl-7 h-8 w-32 text-xs" />
                  </div>
                  <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as any)} className="glass-input h-8 rounded-lg text-xs px-2">
                    <option value="all">Все</option>
                    <option value="active">Активные</option>
                    <option value="deleted">Удалённые</option>
                  </select>
                  <Button variant="ghost" size="icon" className="glass-input h-8 w-8" onClick={() => exportData('users')}><Download className="w-3.5 h-3.5" /></Button>
                </div>
              </div>

              {isLoadingUsers ? (
                <div className="text-center py-6"><div className="w-5 h-5 border-2 border-[var(--primary)]/30 border-t-[var(--primary)] rounded-full animate-spin mx-auto" /></div>
              ) : filteredUsers.length === 0 ? (
                <div className="text-center py-6 text-[var(--muted-foreground)] text-sm"><Users className="w-8 h-8 mx-auto mb-2 opacity-30" />{searchQuery ? 'Ничего не найдено' : 'Нет пользователей'}</div>
              ) : (
                <div className="overflow-x-auto rounded-lg" style={{ background: 'var(--muted)' }}>
                  <table className="w-full text-xs">
                    <thead><tr className="border-b" style={{ borderColor: 'var(--border)' }}><th className="text-left py-2 px-2.5 font-medium text-[var(--muted-foreground)]">Username</th><th className="text-left py-2 px-2.5 font-medium text-[var(--muted-foreground)]">Статус</th><th className="text-left py-2 px-2.5 font-medium text-[var(--muted-foreground)]">Дата</th><th className="text-right py-2 px-2.5 font-medium text-[var(--muted-foreground)]">Действия</th></tr></thead>
                    <tbody>
                      {filteredUsers.map((user) => (
                        <tr key={user.id} className="border-b hover:bg-white/5" style={{ borderColor: 'var(--border)' }}>
                          <td className="py-2 px-2.5 font-mono">{user.username}</td>
                          <td className="py-2 px-2.5"><Badge className={user.isActive ? 'bg-green-500/15 text-green-400 text-[10px]' : 'bg-red-500/15 text-red-400 text-[10px]'}>{user.isActive ? 'Активен' : 'Удалён'}</Badge></td>
                          <td className="py-2 px-2.5 text-[var(--muted-foreground)]">{new Date(user.createdAt).toLocaleDateString('ru-RU')}</td>
                          <td className="py-2 px-2.5 text-right">
                            {user.isActive ? (
                              <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-red-500/10" onClick={() => deleteUser(user.id, user.username)}><Trash2 className="w-3 h-3 text-red-400" /></Button>
                            ) : (
                              <Button variant="ghost" size="icon" className="h-6 w-6 hover:bg-green-500/10" onClick={() => restoreUser(user.id, user.username)}><RotateCcw className="w-3 h-3 text-green-400" /></Button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Webhooks */}
          <TabsContent value="webhooks" className="animate-fade-in">
            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 flex items-center gap-2 text-sm"><Webhook className="w-4 h-4 text-[var(--primary)]" /> Webhook URL</h3>
              <div className="flex gap-2 mb-3">
                <Globe className="w-3.5 h-3.5 text-[var(--muted-foreground)] mt-2.5" />
                <Input placeholder="https://your-server.com/webhook" value={webhookUrl} onChange={(e) => setWebhookUrl(e.target.value)} className="glass-input h-9 flex-1 text-sm" />
              </div>
              <div className="flex gap-2 mb-4">
                <Button className="glass-button h-9 text-xs" onClick={saveWebhook} disabled={isLoadingWebhook}>{isLoadingWebhook ? 'Сохранение...' : 'Сохранить'}</Button>
                {webhookUrl && <Button variant="outline" className="glass-input h-9 text-xs" onClick={() => { setWebhookUrl(''); saveWebhook() }}>Удалить</Button>}
              </div>
              <Separator className="my-3" style={{ background: 'var(--border)' }} />
              <h4 className="font-medium mb-2.5 text-sm">События</h4>
              <div className="grid gap-1.5">
                {['user.registered', 'user.login', 'user.deleted'].map(e => (
                  <div key={e} className="flex items-center justify-between p-2.5 rounded-lg" style={{ background: 'var(--muted)' }}><code className="text-[10px]">{e}</code><Badge variant="outline" className="text-[10px]">Active</Badge></div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Profile */}
          <TabsContent value="profile" className="animate-fade-in space-y-4">
            <div className="glass-card p-5 text-center">
              <div 
                className="avatar avatar-lg mx-auto mb-3 cursor-pointer"
                onClick={() => document.getElementById('avatar-upload-profile')?.click()}
              >
                {avatar ? <img src={avatar} alt="Avatar" /> : client?.email?.[0].toUpperCase()}
              </div>
              <input id="avatar-upload-profile" type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
              <Button variant="outline" size="sm" className="glass-input h-8 text-xs" onClick={() => document.getElementById('avatar-upload-profile')?.click()}>
                <Camera className="w-3.5 h-3.5 mr-1.5" /> Изменить аватар
              </Button>
              <div className="uid-badge mx-auto mt-3 text-sm">UID #{client?.uid}</div>
              <h2 className="text-lg font-bold mt-2 gradient-text">{client?.email}</h2>
              <Badge className="mt-1.5 bg-[var(--primary)]/15 text-[var(--primary)] text-xs">Developer</Badge>
            </div>

            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 text-sm">Информация</h3>
              <div className="grid grid-cols-2 gap-2.5">
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5 flex items-center gap-1"><Database className="w-2.5 h-2.5" /> ID</div>
                  <code className="text-[10px] break-all">{client?.id}</code>
                </div>
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5 flex items-center gap-1"><Clock className="w-2.5 h-2.5" /> Создан</div>
                  <div className="text-xs">{new Date().toLocaleDateString('ru-RU')}</div>
                </div>
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5 flex items-center gap-1"><Shield className="w-2.5 h-2.5" /> Роль</div>
                  <div className="text-xs">Developer</div>
                </div>
                <div className="rounded-lg p-2.5" style={{ background: 'var(--muted)' }}>
                  <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5 flex items-center gap-1"><Globe2 className="w-2.5 h-2.5" /> Статус</div>
                  <Badge className="bg-green-500/15 text-green-400 text-[10px]">Online</Badge>
                </div>
              </div>
            </div>

            {/* Achievements */}
            <div className="glass-card p-4">
              <h3 className="font-medium mb-2.5 flex items-center gap-2 text-sm"><Award className="w-4 h-4 text-yellow-400" /> Достижения</h3>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { icon: Rocket, name: 'Старт', desc: 'Создали аккаунт', unlocked: true },
                  { icon: Key, name: 'Ключ', desc: 'Сгенерировали', unlocked: true },
                  { icon: Users, name: 'Популярный', desc: '10+ юзеров', unlocked: (stats?.totalUsers || 0) >= 10 },
                  { icon: Star, name: 'Активный', desc: '100+ событий', unlocked: (stats?.totalEvents || 0) >= 100 }
                ].map(({ icon: Icon, name, desc, unlocked }) => (
                  <div key={name} className={`p-2.5 rounded-lg text-center ${unlocked ? 'bg-yellow-500/10' : 'opacity-30'}`} style={!unlocked ? { background: 'var(--muted)' } : {}}>
                    <Icon className={`w-5 h-5 mx-auto mb-1 ${unlocked ? 'text-yellow-400' : 'text-[var(--muted-foreground)]'}`} />
                    <div className="text-[10px] font-medium">{name}</div>
                    <div className="text-[9px] text-[var(--muted-foreground)]">{desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Docs */}
          <TabsContent value="docs" className="animate-fade-in">
            <div className="glass-card p-4">
              <h3 className="font-medium mb-3 text-sm flex items-center gap-2"><BookOpen className="w-4 h-4 text-[var(--primary)]" /> Документация API</h3>
              <div className="space-y-5">
                {[
                  { method: 'POST', path: '/api/register', desc: 'Регистрация', code: `fetch('/api/register', {\n  method: 'POST',\n  headers: { 'Content-Type': 'application/json', 'x-api-key': 'YOUR_KEY' },\n  body: JSON.stringify({ username: 'user', password: 'Pass123' })\n})` },
                  { method: 'POST', path: '/api/login', desc: 'Авторизация', code: `fetch('/api/login', {\n  method: 'POST',\n  headers: { 'Content-Type': 'application/json', 'x-api-key': 'YOUR_KEY' },\n  body: JSON.stringify({ username: 'user', password: 'Pass123' })\n})` },
                  { method: 'GET', path: '/api/users', desc: 'Список', code: `fetch('/api/users', {\n  headers: { 'x-api-key': 'YOUR_KEY' }\n})` }
                ].map(({ method, path, desc, code }) => (
                  <div key={path} className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <Badge className={`${method === 'POST' ? 'bg-green-500' : 'bg-blue-500'} text-[10px]`}>{method}</Badge>
                      <code className="text-xs">{path}</code>
                      <span className="text-[10px] text-[var(--muted-foreground)]">{desc}</span>
                    </div>
                    <pre className="rounded-lg p-2.5 overflow-x-auto text-[10px] font-mono" style={{ background: 'rgba(0,0,0,0.3)' }}>{code}</pre>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Admin Panel - только для админов */}
          {client?.role === 'admin' && (
            <TabsContent value="admin" className="animate-fade-in space-y-4">
              <div className="glass-card p-4 border-red-500/20">
                <h3 className="font-medium mb-3 text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4 text-red-400" /> 
                  <span className="text-red-400">Админ Панель</span>
                </h3>
                
                {/* Admin Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                  <div className="stat-card border-red-500/20">
                    <div className="flex items-center gap-2 mb-1.5">
                      <Users className="w-3.5 h-3.5 text-red-400" />
                      <span className="text-xs text-[var(--muted-foreground)]">Всего клиентов</span>
                    </div>
                    <div className="text-xl font-bold text-red-400">{stats?.totalUsers || 0}</div>
                  </div>
                  <div className="stat-card border-red-500/20">
                    <div className="flex items-center gap-2 mb-1.5">
                      <Activity className="w-3.5 h-3.5 text-red-400" />
                      <span className="text-xs text-[var(--muted-foreground)]">Всего событий</span>
                    </div>
                    <div className="text-xl font-bold text-red-400">{stats?.totalEvents || 0}</div>
                  </div>
                  <div className="stat-card border-red-500/20">
                    <div className="flex items-center gap-2 mb-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-red-400" />
                      <span className="text-xs text-[var(--muted-foreground)]">Успешных</span>
                    </div>
                    <div className="text-xl font-bold text-red-400">{stats?.successfulLogins || 0}</div>
                  </div>
                  <div className="stat-card border-red-500/20">
                    <div className="flex items-center gap-2 mb-1.5">
                      <XCircle className="w-3.5 h-3.5 text-red-400" />
                      <span className="text-xs text-[var(--muted-foreground)]">Ошибок</span>
                    </div>
                    <div className="text-xl font-bold text-red-400">{stats?.failedLogins || 0}</div>
                  </div>
                </div>

                {/* Admin Actions */}
                <div className="glass-card p-4 border-red-500/20">
                  <h4 className="font-medium mb-2.5 text-sm flex items-center gap-2">
                    <Zap className="w-4 h-4 text-red-400" /> Быстрые действия
                  </h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="glass-input justify-start h-8 text-xs border-red-500/20 hover:bg-red-500/10" 
                      onClick={async () => {
                        const res = await fetch('/api/client/stats', { headers: { 'Authorization': `Bearer ${token}` } })
                        const data = await res.json()
                        if (data.success) setStats(data.stats)
                        onToast('info', 'Статистика обновлена')
                      }}
                    >
                      <RefreshCw className="w-3.5 h-3.5 mr-1.5 text-red-400" /> Обновить
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="glass-input justify-start h-8 text-xs border-red-500/20 hover:bg-red-500/10" 
                      onClick={() => exportData('audit')}
                    >
                      <Download className="w-3.5 h-3.5 mr-1.5 text-red-400" /> Экспорт логов
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="glass-input justify-start h-8 text-xs border-red-500/20 hover:bg-red-500/10"
                      onClick={() => onToast('info', 'Система работает нормально ✓')}
                    >
                      <CheckCircle className="w-3.5 h-3.5 mr-1.5 text-red-400" /> Статус
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="glass-input justify-start h-8 text-xs border-red-500/20 hover:bg-red-500/10"
                      onClick={() => {
                        localStorage.clear()
                        clearAuth()
                        onToast('success', 'Кэш очищен')
                      }}
                    >
                      <Trash2 className="w-3.5 h-3.5 mr-1.5 text-red-400" /> Очистить кэш
                    </Button>
                  </div>
                </div>

                {/* Admin Info */}
                <div className="glass-card p-4 border-red-500/20">
                  <h4 className="font-medium mb-2.5 text-sm">Информация администратора</h4>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="rounded-lg p-2.5 border border-red-500/20" style={{ background: 'var(--muted)' }}>
                      <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5 flex items-center gap-1">
                        <Shield className="w-2.5 h-2.5 text-red-400" /> Роль
                      </div>
                      <Badge className="bg-red-500/15 text-red-400 text-[10px]">Администратор</Badge>
                    </div>
                    <div className="rounded-lg p-2.5 border border-red-500/20" style={{ background: 'var(--muted)' }}>
                      <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5 flex items-center gap-1">
                        <Hash className="w-2.5 h-2.5 text-red-400" /> UID
                      </div>
                      <div className="uid-badge border-red-500/30">#{client?.uid}</div>
                    </div>
                    <div className="rounded-lg p-2.5 border border-red-500/20 col-span-2" style={{ background: 'var(--muted)' }}>
                      <div className="text-[10px] text-[var(--muted-foreground)] mb-0.5">Email</div>
                      <div className="text-xs truncate">{client?.email}</div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          )}
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t py-3 text-center text-[10px] text-[var(--muted-foreground)]" style={{ borderColor: 'var(--border)', background: 'var(--card)' }}>
        <span className="gradient-text font-medium">Auth Service</span> • API аутентификации для разработчиков
      </footer>

      {/* Dialog */}
      <Dialog open={confirmDialog.open} onOpenChange={(open) => setConfirmDialog(prev => ({ ...prev, open }))}>
        <DialogContent className="glass-card max-w-xs">
          <DialogHeader><DialogTitle className="text-sm">{confirmDialog.title}</DialogTitle></DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="ghost" className="h-8 text-xs" onClick={() => setConfirmDialog(prev => ({ ...prev, open: false }))}>Отмена</Button>
            <Button variant="destructive" className="h-8 text-xs" onClick={() => { confirmDialog.action(); setConfirmDialog(prev => ({ ...prev, open: false })) }}>Подтвердить</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ============================================
// MAIN PAGE
// ============================================
export default function Home() {
  const { client } = useAuthStore()
  const [isRegister, setIsRegister] = useState(false)
  const [toasts, setToasts] = useState<ToastData[]>([])
  const { theme, toggleTheme } = useTheme()

  const addToast = (type: ToastData['type'], message: string) => {
    const id = Date.now().toString()
    setToasts(prev => [...prev, { id, type, message }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000)
  }

  const removeToast = (id: string) => setToasts(prev => prev.filter(t => t.id !== id))

  useEffect(() => {
    fetch('/api/client/register').then(res => res.json()).then(data => {
      if (data.success) console.log('Admin ready, UID:', data.credentials?.uid)
    })
  }, [])

  return (
    <div className={theme === 'light' ? 'theme-light' : theme === 'green' ? 'theme-green' : ''}>
      <CosmicBackground theme={theme} />
      {client ? (
        <Dashboard onToast={addToast} theme={theme} toggleTheme={toggleTheme} />
      ) : isRegister ? (
        <main className="min-h-screen flex items-center justify-center p-4">
          <RegisterForm onToggle={() => setIsRegister(false)} onToast={addToast} />
        </main>
      ) : (
        <main className="min-h-screen flex items-center justify-center p-4">
          <LoginForm onToggle={() => setIsRegister(true)} onToast={addToast} />
        </main>
      )}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </div>
  )
}
