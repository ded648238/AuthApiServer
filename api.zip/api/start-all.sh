#!/bin/bash

echo "Starting Auth Service..."
echo ""

# Kill existing processes
pkill -f "bun.*60023" 2>/dev/null
pkill -f "next.*3000" 2>/dev/null
sleep 1

# Start Next.js backend (port 3000)
echo "Starting Next.js backend on port 3000..."
cd /home/z/my-project
bun run dev 2>&1 | tee -a dev.log &
NEXT_PID=$!

# Wait for Next.js to start
sleep 3

# Start static server (port 60023)
echo "Starting static server on port 60023..."
cd /home/z/my-project/mini-services/static-server
bun run start > /home/z/my-project/static-server.log 2>&1 &
STATIC_PID=$!

sleep 2

echo ""
echo "╔═══════════════════════════════════════════════════════════╗"
echo "║                                                           ║"
echo "║   ✅ All services started!                                ║"
echo "║                                                           ║"
echo "║   Frontend (Static): http://localhost:60023               ║"
echo "║   Backend (API):     http://localhost:3000                ║"
echo "║                                                           ║"
echo "║   Logs:                                                  ║"
echo "║   - /home/z/my-project/dev.log                           ║"
echo "║   - /home/z/my-project/static-server.log                  ║"
echo "║                                                           ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""
echo "Press Ctrl+C to stop all services"

# Wait for processes
wait $NEXT_PID $STATIC_PID
